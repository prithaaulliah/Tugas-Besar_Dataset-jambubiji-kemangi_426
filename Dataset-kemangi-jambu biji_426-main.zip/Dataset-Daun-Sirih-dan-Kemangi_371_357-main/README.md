# DATASET
## Progres dalam minggu ke – 1 
•	Kami telah membuat sebuah kelompok yang beranggotakan 2 orang yaitu  
Dhana Agustya Putra Sasongko (201910370311357) dan Aria Maulana (201910370311371)

•	Kami telah mengambil beberapa foto dari daun sirih dan daun kemangi terkait bahan yang akan digunakan dalam melaksanakan tugas besar pada semester 5 ini.
## Deskripsi
Project ini merupakan sebuah web pendeteksi gambar, yang di bangun menerapkan sistem Artificial intelligence. Dimana Sistem tersebut di buat menggunakan bahasa pemrograman python. Adapun beberapa tahapan dalam membangun sistem tersebut mulai dari mencari dataset sebagai objek sampai menentukan algoritma yang sesuai yang akan diterapkan pada program.

Untuk dataset itu sendiri berupa gambar dedaunan, kali ini kita akan menggunakan 2 label untuk dataset, yakni daun sirih dan daun kemangi. Dibutuhkan 100 foto daun yang terdiri dari 50 foto daun sirih dan 50 foto daun kemangi, adapun kriteria dalam pembuatan dataset yaitu:

•	Image daun diambil menggunakan kamera smartphone

•	Background putih

•	Format .jpg

•	Dimensi 1600 x 1200 pixel

•	Jumlah perlabel 50 gambar
## Anggota
•	Dhana Agustya Putra Sasongko (201910370311357)

•	Aria Maulana (201910370311371)
